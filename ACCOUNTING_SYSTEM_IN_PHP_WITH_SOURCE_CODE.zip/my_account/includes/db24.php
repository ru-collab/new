<?php

$con = mysqli_connect("localhost","root","","my_account");



?>