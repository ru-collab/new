# Employee-Leave-Management-System
It is a simple system coded in php(crud is in oop) that manages the leave request by the employees  


Installation:
-Extract rar file
-copy and paste them in your xammp/lammp htdocs folder
-and go login as employee or an admin

Note:
for login
the id for admin is: 30 password:1
you can add an employee after you login use it as logging in as employee

Developers:
Jan Vince Kyamko
Kim Nengasca
