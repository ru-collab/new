<!DOCTYPE html>
<html>
<head>
	<title>Hospital manangement system</title>
	<!--Favicon-->
	<link rel="stylesheet" type="text/css" href="css/index.css">

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>

</head>
<body id="body">
	


<div id='cssmenu'>
<ul>
   <li><a href='index.php'>Home</a></li>

   <li class='active'><a href='about.php'>About</a></li>
   <li><a href='doctors.php'>Doctors</a></li>
   <li><a href='patients.php'>Patients</a></li>
   <label class="heading">Hospital management system</label>

</ul>
</div>
<p class="para">
 HMS is a completely integrated web enabled Hospital Management System
  suited for large, mid-size hospitals and clinics.
   HMS completely automates and integrates the Hospital's
    entire process catering to, Clinical, Administrative, 
    Support Finance, 
   Supply Chain and Billing functions in the Hospital.
   Hospital Management System provides the benefits of streamlined 
   operations, enhanced administration  control, superior patient care,
    strict cost control and improved profitability.
</p><p class="para">
 HMS is powerful, flexible, easy to use and is designed and developed
 to deliver real conceivable benefits to hospitals and clinics. 
 More importantly it is backed by reliable and dependable  support.
 </p>
</body>